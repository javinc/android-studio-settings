
IonicModule
.service('$ionicNavViewDelegate', ionic.DelegateService([
  'clearCache'
]));

